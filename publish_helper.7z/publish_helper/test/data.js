/**
 * 测试接口数据
 */
var json = {
    isRemind: 0,
    isAdPush: 1,
    topicTitle: '游艇漏气是谁的过错？',
    adText: [
        {
            "text": "救援失职",
            "percent": "70%"
        },
        {
            "text": "天灾人祸",
            "percent": "30%"
        }
    ],
    adBtn: [
        {
            "text": "我也要投票",
            "link": "http://circle.html5.qq.com"
        }
    ],
    common: {
        "guid": "d4a521cf3374f01561e7041a131488cb",
        "qua": "ADRQBX53_P/530836&X5MTT_3/025300&ADR&305013&GT-I9118&0&9317&Android4.2.2&V3",
        "channelId": "1",
        "sourceId": "1",
        "mtId": "1",
        "originalUrl": "http://circle.html5.qq.com"
    }
};
module.exports = json;