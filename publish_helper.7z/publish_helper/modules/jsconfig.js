/**
 * Created by brianzheng on 2015/8/3.
 */
var Config = {};
Config = {
    baseUrl: "http://adsense.imtt.qq.com/ajax",
    qqapi: "http://pub.idqqimg.com/qqmobile/qqapi.js?_bid=152",
    tbsapi: "http://res.imtt.qq.com/tbs/tbs.js",
    qbapk: "com.tencent.mtt",
    qqapk: "com.tencent.mobileqq",
    posId: 15
};
module.exports = Config;